/**
 * @file
 * Contains js for the accordion example.
 */

(function ($) {
  $(function () {
    $("#accordion").accordion();
  })
})(jQuery);
